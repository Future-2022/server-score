module.exports = {
  jwtSecret:'secret'
}